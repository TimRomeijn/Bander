var functions = {
     

    getProfileData : function() {
        
    }
}